<?php
	require_once 'db_connect.php';
	include_once 'header.php';
	include_once 'navigation.php';
	
	$productID = $_GET['ProductID'];
	$categoryID = $_GET['CategoryID'];
	$query = "select ProductID, ProdName, CategoryID, ProdLeft, ProdPrice, ProdImage, ProdDescription from Product where ProductID = $productID";
	$result = mysql_query($query);	
	$row = mysql_fetch_array($result, MYSQL_ASSOC);
	
	if ($row) {	
	echo "<div id='main'><table>";
echo "<tr><td><a href='".ALLLINK."showDetail.php?CategoryID={$row['CategoryID']}&ProductID={$row['ProductID']}'><img src='{$row['ProdImage']}' alt=\"Product Image\" width='150' height='150'></a></td>\n
		<td style='width: 500px;'><p style='font-size: 12px;'><a href='".ALLLINK."showDetail.php?CategoryID={$row['CategoryID']}&ProductID={$row['ProductID']}' ><strong >{$row['ProdName']}</strong></a></p><p>{$row['ProdDescription']}</p></td>\n";
		echo "<td style='width: 150px;'><div>Giá tiền: <strong>{$row['ProdPrice']}</strong></div></p><p>Trạng thái: ";
		if ($row['ProdLeft'] > 0) echo "Còn hàng<br /><br/>";
		else echo "Hết hàng</p>";
		echo "<div style='color: red;'><img class='purchasebtn' src='images/purchase.png' alt='Purchase' />Mua"; //nut mua hang
		echo "<form class='purchaseForm' action='user/purchase.php' method='post'>
		Số lượng: <input id='amount' name='Amount' type='text' size='3' /><br />
		<input type='submit' value='Mua' style='font-size: 10px;'/>
		<input type='hidden' name='ProductID' value='{$row['ProductID']}' />
		</form></div>"; //form mua hang
		echo "</td></tr>";
	echo "</table>";	
	echo "<script>
		$('.purchasebtn').toggle(function() {
			$(this).parent().children(':last').show();
			//$(this).parent().;
		}, function() { $(this).parent().children(':last').hide(); });
		
		$('form.purchaseForm').submit(function() {
			if ( isNaN($('form #amount').val()) || !$('form #amount').val()) {
				alert('Xin vui lòng nhập số!');
				$('form #amount').focus();
				return false;
			}
			return true;
		});
		$('.')
	</script>";
	echo "
	<div id='comment' style='margin-top: 20px;'>\n <!--comment form-->
		<p>Cảm nhận về sản phẩm</p>\n
		<span class='error'></span>\n
		<form id='commentform' action='".USERLINK."comment.php' method='post' >\n
			<textarea id='content' name='content' rows='10' cols='40'></textarea><br/>\n";
	echo "<input type='hidden' name='ProductID' value='$productID' />\n";
	echo "<input type='hidden' name='CategoryID' value='$categoryID' />";
	echo "
			<input type='submit' value=\"Góp ý\" />\n
		</form>\n
		<script>\n
			$('#commentform').submit(function() {\n
				var str = $('#content').val();
				if (!str) {\n
					$('span.error').text('- Vui lòng nhập comment!');\n
					return false;
				}\n
				return true;
			});\n
		</script>\n
	</div>";
	}
	else {
		echo "<p style='text-align: center;'>Không tìm thấy sản phẩm nào!</p>";
	}
	echo "</div><!--end main div-->"; //end main div
	include_once 'footer.php';
	mysql_close($link);
?>
