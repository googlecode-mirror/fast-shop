<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>FastShop</title>
<?php echo "<link rel='stylesheet' type='text/css' href='".$fixdir."css/template.css' />";
echo "<script type='text/javascript' src='".$fixdir."jquery.min.js' /></script>";
?>
<script type='text/javascript'>
	$(document).ready(function() {
		$('#navMain ul > li > ul').hide();
		$('#openCates > ul').show();
		//$('#navMain ul li ul:first').show();
		$('#navMain ul > li > h4').click(function() {
			$(this).next().toggle();
		});
		slideShow();
	});
	
	function slideShow() {
 		var current = $('#slideShow a.show');
		var next = current.next().length ? current.next() : current.parent().children(':first');
 		current.hide().removeClass('show');
 		next.fadeIn().addClass('show');
  		setTimeout(slideShow, 3000);
	}		
</script>
</head>

<body>
<div id='header'>
<div id='loginPlace'>
	Xin chào, 
	<?php
	if (isset($_COOKIE['name'])) {
		echo "<a href='".USERLINK."personalInfo.php') >{$_COOKIE['name']}</a>";
		echo "<br /><a href='".USERLINK."logout.php' >Đăng xuất</a>";
	}
	else {
		echo "Khách<br/><a href='".USERLINK."login.php' >Đăng nhập</a> hoặc
		<a href='".$fixdir."signup.php'>Đăng ký</a>";
	}
	?>
</div>
<?php
	echo "<div id='navHeader'>
	<span><a href='".ALLLINK."index.php'>Trang chủ</a></span>
	<span><a href='".ALLLINK."bestseller.php'>Sản phẩm bán chạy</a></span>
	<span><a href='".ALLLINK."discount.php'>Giảm giá</a></span>
	<span style=\"border-right: none;\"><a href='".ALLLINK."help.php'>Trợ giúp</a></span>
</div>
<form action='".ALLLINK."search.php' method='get'>
	<input id='searchBox' type='text' name='searchBox' size='60' >&nbsp;<input type='submit' value=\"Tìm kiếm\" />
</form>
</div> <!--end header-->
";
?>

