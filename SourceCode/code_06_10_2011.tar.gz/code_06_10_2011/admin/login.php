<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Control Panel</title>
<script type='text/javascript' src='jquery.min.js'></script>
<style type='text/css'>
	body {
		font-family: venada, helvetica, sans-serif;
		font-size: 14px;
		color: #000;
	}
	span.error {
		color: red;
	}
</style>
</head>

<body>
<?php
	require_once 'db_connect.php';
	if (isset($_POST['submitted'])) {
		$username = $_POST['username'];
		$password = $_POST['password'];
		$query = "select AdUsername, AdPassword from Admin where AdUsername = '$username' and AdPassword = sha1('$password')";
		$result = mysql_query($query);
		if (!mysql_num_rows($result)) {
			echo "<script>alert('Sai username hoặc password! Vui lòng nhập lại!');
			//window.location = 'login.php';</script>";
		}
		else {
			$row = mysql_fetch_array($result, MYSQL_ASSOC);
			setcookie('username', $username, time()+86400, '/', '', 0, 0);
			setcookie('password', $password, time()+86400, '/', '', 0, 0);
			echo "<script>alert('Bạn đã đăng nhập thành công!');
			window.location = 'index.php';</script>";			
		}
		exit();
	}
?>
<div id='main' style='text-align: center;'>
	<p>Đăng nhập:</p>
	<div>
	<span class='error'></span>
	<form id='loginform' action='login.php' method='post'>
		<table align="center">
		<tr><td>Username: </td><td><input id='username' name='username' type='text' size='20' maxlength="50"/></td></tr>
		<tr><td>Password: </td><td><input id='password' name='password' type='password' size='20' maxlength="50"/></td></tr>
		<tr><td colspan="2" style='text-align: center;'><input type='hidden' name='submitted' value='true' /><input type='submit' value="Đăng nhập" /></td></tr>
		</table>
	</form>
	<script>
		$('#loginform').submit(function() {
			if (!$('#username').val()) {
				$('span.error').text('- Vui lòng nhập username!').show();
				return false;
			}
			if (!$('#password').val()) {
				$('span.error').text('- Vui lòng nhập password!').show();
				return false;
			}
			return true;
		});
	</script>
	</div>
</div>
</body>
</html>
