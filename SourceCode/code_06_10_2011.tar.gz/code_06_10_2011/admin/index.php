<?php
	if (!isset($_COOKIE['username']) || !isset($_COOKIE['password'])) {
		echo "<script>	window.location = 'login.php';</script>";
		exit();
	}
	echo "
<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01//EN\" \"http://www.w3.org/TR/html4/strict.dtd\">
<html>
<head>
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">
<title>Control Panel</title>

<frameset rows=\"90, *\" marginwidth='0' marginheight='0' frameborder='0' border='0' borderwidth='0'>
	<frame name='head' src='head.php' scrolling=no>
<frameset cols=\"170, *\" marginwidth='0' marginheight='0' frameborder='0' border='0' borderwidth='0'>
	<frame name='navi' src='navi.php' scrolling=no>
	<frame name='main' src='main.php' marginwidth='20'>
</frameset>
</frameset>

</head>

<body>
</body>
</html>";
?>
