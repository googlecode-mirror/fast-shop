<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link href='css/cpanel.css' rel='stylesheet' type='text/css' />
</head>

<body style="background-color: #f8e8a0;">
<div id='main'>
	<p>Welcome to control panel</p>
</div>
</body>
</html>
