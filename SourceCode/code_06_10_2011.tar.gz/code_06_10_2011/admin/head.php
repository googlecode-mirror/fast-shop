<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href='css/cpanel.css' rel='stylesheet' type='text/css' />
</head>

<body style="background: #fff; margin-top: 8px; margin-left: 8px">
<?php
	$name = $_COOKIE['username'];
echo "
<div id='head'>
<div id='smallPanel'>
	<span>Chào mừng tới Control Panel, $name</span><br/>
	<a href='logout.php' target='_parent'>Đăng xuất</a><br/>
	<a href='personal/information.php' target='main'>Thông tin cá nhân</a>
</div>
<h1><strong>Control</strong> Panel</h1>
</div>";
?>
</body>
</html>
