<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Control Panel</title>
<link type='text/css' rel='stylesheet' href='../css/mainframe.css' />
</head>

<body>
<?php
	include '../db_connect.php';
	
	$comID = $_GET['CommentID'];
	$query = "update Comment set ComStatus = 'submitted' where CommentID = $comID";
	
	if (!mysql_query($query)) {
		if (!LIVE) {
			echo mysql_errors($link);
		}
	}
	mysql_close($link);
	echo "<script>alert('Submit thành công!');
	window.location = 'listComment.php';
	</script>";
?>
</body>
</html>
