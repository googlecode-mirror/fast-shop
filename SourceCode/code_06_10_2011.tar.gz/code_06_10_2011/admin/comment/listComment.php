<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Control Panel</title>
<link type='text/css' rel='stylesheet' href='../css/mainframe.css' />
<style type='text/css'>
	a:link {
		text-decoration: none;
	}
</style>
</head>

<body>
<?php
	include_once '../db_connect.php';
	
	$display = 5; //số lượng comment trên mỗi trang
	
	//xác định số lượng trang
	if (isset($_GET['p']) && is_numeric($_GET['p'])) {
		$pages = $_GET['p'];
	}
	else {
		//query để tính số lượng trang
		$query = "select count(CommentID) from Comment
			 where ComStatus = 'pending'";
		$result = mysql_query($query);
		
		$row = mysql_fetch_array($result, MYSQL_NUM);
		$numOfCom = $row[0];
		
		$pages = ceil($numOfCom / $display);
	}
	//xác định vị trí bắt đầu
	if (isset($_GET['s']) && is_numeric($_GET['s'])) {
		$start = $_GET['s'];
	}
	else {
		$start = 0;
	}
	//hiển thị danh sách comment, thêm đuôi limit $start, $display cho query
	$query = "select CommentID, ProdName, CusUsername, ComContent, ComStatus
	from Customer as Cu
	 right outer join Comment as Co
	  on Cu.CustomerID = Co.CustomerID
	 left join Product as Pr
	  on Co.ProductID = Pr.ProductID
	 where ComStatus = 'pending'
	order by ProdName
	limit $start, $display";
	$result = mysql_query($query);
	
	if (!$result) {
		if (!LIVE) {
			echo mysql_errors($link);
		}
	}
	echo "<table><tr><td>CommentID</td><td>Product Name</td><td>Username</td><td>Content</td><td>Status</td><td>Submit</td><td>Cancel</td></tr>";
	while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
		echo "<tr>\n";
		echo "<td>{$row['CommentID']}</td><td>{$row['ProdName']}</td><td>{$row['CusUsername']}</td><td id='contentCell'>{$row['ComContent']}</td><td>{$row['ComStatus']}</td><td><a href='submitComment.php?CommentID={$row['CommentID']}'>Submit</a></td><td><a href='cancelComment.php?CommentID={$row['CommentID']}'>Cancel</a></td>";
		echo "</tr>";
	}
	echo "</table>";
	//viết danh sách số trang
	if ($pages > 1) {
		echo "<br/><p>";
		//xác định trang hiện tại để có thể hiện link Trước hoặc Tiếp và số của trang hiện tại sẽ ko phải là 1 link
		$currentPage = ($start / $display) + 1;
		if ($currentPage > 1) {
			echo "<a target='main' href='listComment.php?p=$pages&s=" .($start - $display). "'>Trước &nbsp;&nbsp;</a>";
		}
		for ($i = 1; $i <= $pages; $i++) {
			if ($i != $currentPage) {
				echo "<a target='main' href='listComment.php?p=$pages&s=" .($display * ($i - 1)). "'>$i &nbsp;&nbsp;</a>";
			}
			else {
				echo "$i &nbsp;&nbsp;";
			}
		}
		
		if ($currentPage < $pages) { //chưa tới trang cuối
			echo "<a target='main' href='listComment.php?p=$pages&s=" .($start + $display). "'>Tiếp &nbsp;&nbsp;</a>";
		}
		echo "</p>";
	}
	mysql_close($link);
?>
</body>
</html>
