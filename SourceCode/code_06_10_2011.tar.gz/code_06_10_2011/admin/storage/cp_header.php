<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Control Panel</title>
<link rel='stylesheet' type='text/css' href='css/cpanel.css' />
<script type='text/javascript' src='validFunctions.js'></script>
</head>

<body>
<div id='cp_header'>
	<p>Control Panel, Hello, Admin<br/>
	<a href='#'>Log out</a>
	</p>
</div>

