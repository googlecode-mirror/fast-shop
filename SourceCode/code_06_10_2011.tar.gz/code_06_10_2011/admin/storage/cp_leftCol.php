<div id='cp_leftCol'>
	<ul>
		<li>Business
			<ul>
				<li><a href='#'>List Orders</a></li>
				<li><a href='#'>Manage Product</a></li>
				<li><a href='#'>Manage Discount</a></li>
				<li><a href='#'>Reveneu Statistics</a></li>
				<li><a href='#'>Profit Statistics</a></li>
			</ul>
		</li>
		<li>Personal
			<ul>
				<li><a href='index.php?function=personalInfo'>Personal Information</a></li>
			</ul>
		</li>
	</ul>
</div>
