<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link href='css/cpanel.css' rel='stylesheet' type='text/css' />
</head>

<body style="background-color: #fb7922;">
<div id='navi'>
<ul>
	<li><p style="font-size: 18px; border-bottom: 1px dashed;">Control Panel<p>
		<ul>
			<li><a href='#'>Liệt kê đơn hàng</a></li>
			<li><a href='#'>Quản lý sản phẩm</a></li>
			<li><a href='#'>Quản lý chương trình khuyến mại</a></li>
			<li><a href='#'>Thống kê</a></li>
			<li><a href='comment/listComment.php' target='main'>Quản lý comment</a></li>
			<li><a href='#'></a></li>
		</ul>
	</li>
</ul>
</div>
</body>
</html>
