<?php
	define('HOST', 'localhost');
	define('USER', 'root');
	define('PASS', '333333333');
	define('DB', 'FastShop');
	define('LIVE', false);
	define('USERLINK', 'http://'.HOST.'/code/user/');
	define('ALLLINK', 'http://'.HOST.'/code/');
	define('BESTSELLER', 10);
	$display = 3;
	
	$fixdir = '';
	
	if (LIVE)
		ini_set('display_errors', 0);
	else {
		ini_set('display_errors', 1);
		error_reporting(E_ALL);
	}
	$link = mysql_connect(HOST, USER, PASS);
	mysql_query("set character_set_results = utf8", $link);
	if (!$link) {
		die( 'Not connected: '.mysql_error());
	}
	mysql_select_db(DB, $link) or die ('Can\'t use '.DB.'!');
?>
