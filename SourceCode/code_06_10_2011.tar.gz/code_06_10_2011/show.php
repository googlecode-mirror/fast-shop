<?php
	require_once 'db_connect.php' ;
	include_once 'header.php';
	include_once 'navigation.php';
	
	if (isset($_GET['CategoryID']) && is_numeric($_GET['CategoryID'])) { //lấy thông tin về category id
		$categoryID = $_GET['CategoryID'];
	}
	else {
		$categoryID = 1;
	}
	if (isset($_GET['p']) && is_numeric($_GET['p'])) {//lấy thông tin về số lượng trang
		$pages = $_GET['p'];
	}
	else {//nếu không có thì phải query để tính toán
		$query = "select count(ProductID)
			from Product
			where CategoryID = $categoryID";
		$result = mysql_query($query);
		$row = mysql_fetch_array($result, MYSQL_NUM);
		$numOfProd = $row[0];
		
		$pages = ceil($numOfProd / $display);
	}
	
	if (isset($_GET['s']) && is_numeric($_GET['s'])) {
		$start = $_GET['s'];
	}
	else {
		$start = 0;
	}

	$query = "select ProductID, ProdName, CategoryID, ProdLeft, ProdPrice, ProdImage, ProdDescription from Product where CategoryID = $categoryID
	limit $start, $display";
	
	$result = mysql_query($query);
	
	echo "<div id='main'><table>";
	while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
		echo "<tr><td><a href='".ALLLINK."showDetail.php?CategoryID={$row['CategoryID']}&ProductID={$row['ProductID']}'><img src='{$row['ProdImage']}' alt=\"Product Image\" width='150' height='150'></a></td>\n
		<td style='width: 500px;'><p style='font-size: 12px;'><a href='".ALLLINK."showDetail.php?CategoryID={$row['CategoryID']}&ProductID={$row['ProductID']}' ><strong >{$row['ProdName']}</strong></a></p><p>{$row['ProdDescription']}</p></td>\n";
		echo "<td style='width: 150px;'><div>Giá tiền: <strong>{$row['ProdPrice']}</strong></div></p><p>Trạng thái: ";
		if ($row['ProdLeft'] > 0) echo "Còn hàng<br /><br/>";
		else echo "Hết hàng</p>";
		echo "<div style='color: red;'><img class='purchasebtn' src='images/purchase.png' alt='Purchase' />Mua"; //nut mua hang
		echo "<form class='purchaseForm' action='user/purchase.php' method='post'>
		Số lượng: <input id='amount' name='Amount' type='text' size='3' /><br />
		<input type='submit' value='Mua' style='font-size: 10px;'/>
		<input type='hidden' name='ProductID' value='{$row['ProductID']}' />
		</form></div>"; //form mua hang
		echo "</td></tr>";
	}
	echo "</table>";	
	echo "<script>
		$('.purchasebtn').toggle(function() {
			$(this).parent().children(':last').show();
			//$(this).parent().;
		}, function() { $(this).parent().children(':last').hide(); });
		
		$('form.purchaseForm').submit(function() {
			if ( isNaN($('form #amount').val()) ||  !$('form #amount').val()) {
				alert('Xin vui lòng nhập số!');
				$('form #amount').focus();
				return false;
			}
			return true;
		});
		$('.')
	</script>";
	//bắt đầu viết danh sách các số trang, có thể có nút Previous, Next
	echo "<br /><p style='text-align: right;'>";
	//xác định current page
	if ($pages > 1) {
		$currentPage = ceil($start / $display) + 1;
	
		if ($currentPage > 1) {
			echo "<a href='show.php?CategoryID=$categoryID&p=$pages&s=".($start - $display)."'>Trước&nbsp;&nbsp;</a>";
		}
		for ($i = 1; $i <= $pages; $i++) {
			if ($i != $currentPage) {
				echo "<a href='show.php?CategoryID=$categoryID&p=$pages&s=".($display * ($i - 1))."'>$i&nbsp;&nbsp;</a>";
			}
			else {
				echo "$i &nbsp;&nbsp;";
			}
		}
		
		if ($currentPage < $pages) {
			echo "<a href='show.php?CategoryID=$categoryID&p=$pages&s=".($start + $display)."'>Tiếp&nbsp;&nbsp;</a>";
		}
	}
	echo "</p>";
	echo "</div>"; //end main div
?>

<?php
	include_once 'footer.php';
	mysql_close($link);
?>
