<?php
	require_once 'db_connect.php' ;
	include_once 'header.php';
	include_once 'navigation.php';

	$query = "select A.ProductID, CategoryID, ProdPrice, Sold, A.ProdPrice * B.Sold as Total, ProdImage, ProdName, month(now()) as Month
 from 
  (select ProductID, CategoryID, ProdPrice, ProdImage, ProdName
   from Product) as A
    inner join 
  (select ProductID, sum(Amount) as Sold
   from FastShop.Order
   where OrdStatus = 'submitted' and month(OrdDate) = month(now()) - 1
    group by ProductID
    having sum(Amount) > ".BESTSELLER.") as B
     on A.ProductID = B.ProductID
 order by Total desc
 limit 0, 5";
	echo "<div id='bestsellerCol'>
		<h3><a href='bestseller.php'>Bán chạy nhất</a></h3><br/>";
	$result = mysql_query($query);
	if ($result) {
		echo "<table align='center'>";
		while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
			echo "<tr><td><a href='showDetail.php?CategoryID={$row['CategoryID']}&ProductID={$row['ProductID']}'><img src='{$row['ProdImage']}' alt='Product Image' style='border: 2px solid black'/></a></td></tr>";
		}
		echo "</table>";
	}
	echo "</div><!--end bestsellerCol-->";
?>
<div id='main' style="margin-left: 260px;">
<div id='slideShow'>
	<a href='#' class='show'><img  src='images/hp_1.jpg' alt='image' /></a>
	<a href='#'><img src='images/hp_2.jpg' alt='image' /></a>
	<a href='#'><img src='images/hp_3.jpg' alt='image' /></a>
</div>
</div>
<?php
	include_once 'footer.php';
	mysql_close($link);
?>
