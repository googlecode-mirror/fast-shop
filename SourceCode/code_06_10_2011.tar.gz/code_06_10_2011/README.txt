Cách cài đặt trang FastShop: (phiên bản 1.0.5)
	1. Vào phpmyadmin tạo database tên là FastShop
	2. Click vào database đó rồi chọn mục SQL, copy toàn bộ code trong file 2011-10-05.sql vào trong vùng text
	rồi chạy.
	3. Vào thư mục code, mở file db_connect.php, đổi password của root mà được cài đặt trên máy tính của bạn,
	chỉnh sửa tương tự với file db_connect.php trong thư mục code/admin để có thể chạy được trang admin
Tài khoản để thực hiện việc chạy thử chức năng đăng nhập và mua bán:
	username: hung
	password: hung
Các bạn cũng có thể tự tạo tài khoản cho riêng mình bằng cách chỉnh sửa database. Rất tiếc là chưa có chức năng
	đăng ký vì bạn Thạch gà quá.
Mọi thắc mắc xin liên hệ với Hùng qua địa chỉ email: hung_nguyenvan30@yahoo.com

Các chức năng đã hoàn thành:
	Hiện sản phẩm, phân trang
	Đăng nhập
	Đăng xuất
	Comment
	Quản lý comment
	Mua bán
	

