<?php
echo "
<div id='footer'>
	<div id='navFooter'>
		<span><a href='#header'>Trở lại top</a></span>
		<span><a href='".ALLLINK."index.php'>Trang chủ</a></span>
		<span style='border-right: none;'><a href='".ALLLINK."help.php' style='padding-left: 5px;'>Trợ giúp</a></span>
	</div>
	<p>
		Thông tin liên hệ
	</p>
</div>
</body>
</html>";
?>
