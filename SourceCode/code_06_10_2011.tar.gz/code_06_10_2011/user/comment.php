<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>FastShop</title>
</head>

<body>
<?php
	require_once '../db_connect.php';
	
	if (!isset($_COOKIE['username'])) {
		echo "<script>alert('Để comment, bạn cần phải đăng nhập!');";
		echo "window.location = 'login.php';</script>";
	}
	else {
		$categoryID = $_POST['CategoryID'];
		$productID = $_POST['ProductID'];
		$content = $_POST['content'];
		$customerID = $_COOKIE['userid'];
		
		$query = "insert into Comment (CustomerID, ProductID, ComContent) values($customerID, $productID, '$content')";
		echo $query;
		$result = mysql_query($query);
		if (!$result) {
			if (!LIVE) {
				echo mysql_error($link);
			}
			echo "<script> alert('Có lỗi xảy ra, xin lỗi quý khách!');";
			echo "	window.location = '../showDetail.php?CategoryID=$categoryID&ProductID=$productID';</script>";			
		}
		else {
			echo "<script>alert('Cảm ơn bạn đã comment!');";
			echo "	window.location = '../showDetail.php?CategoryID=$categoryID&ProductID=$productID';</script>";
		}
	}
	
	mysql_close($link);
?>
</body>
</html>
