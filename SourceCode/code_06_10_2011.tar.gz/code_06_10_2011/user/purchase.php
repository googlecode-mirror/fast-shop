<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title></title>
</head>

<body>
<?php
	include_once '../db_connect.php';
	if (!isset($_COOKIE['username']) || !isset($_COOKIE['password'])) {
		echo "<script>	alert('Để mua hàng bạn cần phải đăng nhập!');
		window.location = 'login.php';</script>";
		exit();
	}
	
	$amount = $_POST['Amount'];
	$productID = $_POST['ProductID'];
	$userID = $_COOKIE['userid'];
	
	$query = "select P.CategoryID, P.ProductID, ProdPrice, case when D.Percent is null then 0 else D.Percent end as Percent
	from Discount as D
 		right join Product as P
  			on D.ProductID = P.ProductID and D.StartDate < now() < D.EndDate
	where P.ProductID = $productID";

	$result = mysql_query($query);
	if (!$result) {
		echo "<script>Sản phẩm bạn yêu cầu không tồn tại!</script>";
		exit();
	}
	$row = mysql_fetch_array($result, MYSQL_ASSOC);
	$lastPrice = $row['ProdPrice']  -  $row['ProdPrice'] * $row['Percent']/100;
	$total = $lastPrice * $amount;
	$categoryID = $row['CategoryID'];
		
	$query  = "insert into FastShop.Order(CustomerID, ProductID, OrdPrice, Amount) values($userID, $productID, $total, $amount) ";
	$result = mysql_query($query);
	if (!$result) {
		if (!LIVE) {
			echo mysql_error($link);
		}
	}
	else {
		echo "<script>
			alert(\"Cảm ơn đã tin dùng sản phẩm của chúng tôi! Admin sẽ gọi điện cho bạn để xác nhận giao dịch.\");
			window.location = '../showDetail.php?CategoryID=$categoryID&ProductID=$productID';
		</script>";
	}
?>
</body>
</html>
