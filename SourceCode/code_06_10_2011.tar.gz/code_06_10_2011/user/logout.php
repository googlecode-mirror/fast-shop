<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>FastShop</title>
</head>

<body>
<?php
	$fixdir = '../';
	if (isset($_COOKIE['username'])) {
	setcookie('username', '', time()-86400, '/', '', 0, 0);
	setcookie('password', '', time()-86400, '/', '', 0, 0);
	setcookie('name', '', time()-86400, '/', '', 0, 0);
	setcookie('userid', '', time()-86400, '/', '', 0, 0);
	
	echo "<script>alert('Đăng xuất thành công! Hẹn gặp lại bạn!');
	window.location = '".$fixdir."index.php';</script>";
	}
	else {
		echo "<script>window.location = '".$fixdir."index.php';</script>";
	}
?>
</body>
</html>
