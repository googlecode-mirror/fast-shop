<?php
	include_once 'db_connect.php';
	include_once 'header.php';
	include_once 'navigation.php';

	/*Bestseller là sản phẩm bán chạy nhất so với tất cả các sản phẩm khác cho dù khác loại, và có số lượng đã bán > 10, (số lượng đã bán * giá tiền) là cao nhất. Thống kê bestseller ở tháng trước*/
echo "<div id='main'>";
	$query = "select A.ProductID, CategoryID, ProdPrice, Sold, A.ProdPrice * B.Sold as Total, ProdImage, ProdName, month(now()) as Month
 from 
  (select ProductID, CategoryID, ProdPrice, ProdImage, ProdName
   from Product) as A
    inner join 
  (select ProductID, sum(Amount) as Sold
   from FastShop.Order
   where OrdStatus = 'submitted' and month(OrdDate) = month(now()) - 1
    group by ProductID
    having sum(Amount) > ".BESTSELLER.") as B
     on A.ProductID = B.ProductID
 order by Total desc
 limit 0, 5";
	
	$result = mysql_query($query);
	if(!$result) {
		echo "<h3>Không có sản phẩm bán chạy nhất!</h3>";
	}
	else {
		echo "<h3>Những sản phẩm bán chạy nhất tháng ".(date("n") - 1)."</h3><br/>";
		echo "<table>";
		while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
			echo "<tr><td><a href='showDetail.php?CategoryID={$row['CategoryID']}&ProductID={$row['ProductID']}'><img src='{$row['ProdImage']}' alt='Product Image'</a></td><td><a href='showDetail.php?CategoryID={$row['CategoryID']}&ProductID={$row['ProductID']}'>{$row['ProdName']}</a></td></tr>";
		}
		echo "</table>";
	}
echo "</div>";

	include_once 'footer.php';
	mysql_close($link);
?>
